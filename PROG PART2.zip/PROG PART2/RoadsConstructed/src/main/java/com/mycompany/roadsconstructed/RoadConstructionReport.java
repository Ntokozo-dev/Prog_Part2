
package com.mycompany.roadsconstructed;
//subclass that extends the RoadsConstructed class
public class RoadConstructionReport extends RoadsConstructed {
    //constructor that takes city and totals... and calls super to access all other classes
    public RoadConstructionReport(int total, String city) {
        super(total, city);
    }
    //method to print the report
    public void printRoadsConstructedReport (){
     //output  
    System.out.println("ROAD CONSTRUCTION REPORT");
    System.out.println("************************************************************************");
    System.out.println("CITY: " + getCity());//print this using getCity()
    System.out.println("ROADS CONSTRUCTED:" + getTotalRoadsConstructed());//print this using gTRC()
    System.out.println("************************************************************************");
    
}
}