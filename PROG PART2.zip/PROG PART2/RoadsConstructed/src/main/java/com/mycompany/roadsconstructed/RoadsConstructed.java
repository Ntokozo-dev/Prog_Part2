
package com.mycompany.roadsconstructed;

public abstract class RoadsConstructed implements IRoadsConstructed  {
    //variables containing the city and the totals
   private String city;
   private int totalRoadsConstructed;
   //Constructor that accepts the city and totals as parameters
    public RoadsConstructed (int total, String city) {
        this.city = city;
        this.totalRoadsConstructed = total;
    }  
    //get method to get the city input
    public String getCity (){
        return city;
    }         
    //get method to get the total number of road constructed input      
    public int getTotalRoadsConstructed (){
        return totalRoadsConstructed;
    }
    
    }

