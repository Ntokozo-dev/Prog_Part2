
package com.mycompany.roadsconstructed;
//interface class to be implemented by the RoadsConstructed classs
public interface IRoadsConstructed {
    //two method signatures
 String getCity();
 int getTotalRoadsConstructed();   
}
