
package com.mycompany.roadsconstructed;
import java.util.Scanner;//scanner for reading user input
//class to instantiate the RoadCondtructionReport class
public class RunApplication {

public static void main (String[] args){
 Scanner scanner = new Scanner (System.in);//calls the scanner
 
      // prompt user to input city name
    System.out.println("Please enter the name of city");
    String city = scanner. nextLine();//reads input
    
    // prompt user to input the total number of road construction 
    System.out.println("Please enter the total number of road constructed");
    String totalRoadsConstructed = scanner. nextLine();//reads input
    
     //scanner expects an int but above i have a string to convert that string to an int
    int total = Integer.parseInt(totalRoadsConstructed);
    
 //object to access totals and city data   
 RoadConstructionReport report = new RoadConstructionReport (total, city);
      report.printRoadsConstructedReport();
}
}
