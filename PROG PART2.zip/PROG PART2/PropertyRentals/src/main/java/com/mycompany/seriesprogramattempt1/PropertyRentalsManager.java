
package com.mycompany.seriesprogramattempt1;

import java.util.Scanner;
import java.util.ArrayList;

public class PropertyRentalsManager {

// Used to read input from the user
    Scanner scanner = new Scanner(System.in);

    // Stores all captured properties in memory
    ArrayList<PropertyModel> propertyList = new ArrayList<>();
//Validates rental amount  to return true if it is 1500 and/or above 
    public boolean isRentalAmountValid(double amount) {
        return amount >= 1500;
    }

//Captures property details from the user and saves to propertyList   
    public void EnterProperty() {
        PropertyModel propertyModel = new PropertyModel();

        // Capture property ID
        System.out.println("--------------------------------------------");
        System.out.println("Enter the property ID: ");
        String PropertyId = scanner.nextLine();
        propertyModel.PropertyId = PropertyId;

        // Capture property address
        System.out.println("---------------------------------------------------");
        System.out.println("Enter the property address: ");
        String propertyAddress = scanner.nextLine();
        propertyModel.PropertyAddress = propertyAddress;

        // Capture + validate rental amount
        double rentalAmount = 0;
        String propertyRentalAmount = "";

        do {
            System.out.println("----------------------------------------------");
            System.out.println("Enter the property rental amount: ");
            propertyRentalAmount = scanner.nextLine();
            

            try {
                rentalAmount = Double.parseDouble(propertyRentalAmount);

                // Validate the range
                if (!isRentalAmountValid(rentalAmount)) {
                    System.out.println("-------------------------------------------");
                    System.out.println("You have entered an invalid amount!!!");
                    System.out.println("Please re-enter property rental amount");
                }

            } catch (NumberFormatException e) {
                // If user entered letters/symbols error handles
                rentalAmount = 0;
                System.out.println("-------------------------------------------");
                System.out.println("You have entered an invalid amount!!!");
                System.out.println("Please re-enter property rental amount");
            }

        } while (!isRentalAmountValid(rentalAmount));
        propertyModel.PropertyRentalAmount = rentalAmount;
        
        // Capture Agent name 
        String agentName = "";

            System.out.print("Enter the property agent name: ");
            agentName = scanner.nextLine();

        // Store episodes as String based on the seriesModel
        propertyModel.AgentName = agentName;

        // Save property to list
        System.out.println("---------------------------------------------");
        System.out.println("New property details have been processed SUCCESSFULLY !!!");
        propertyList.add(propertyModel);
    
    }
    
    //Searches for a property by reading the propertyId from user input.
    public PropertyModel SearchProperty() {
        System.out.println("Enter the propertyId to search: ");
        String searchProperty = scanner.nextLine();

        for (PropertyModel property : propertyList) {
            if (property.PropertyId.equals(searchProperty)) {

                // Print details when found
                System.out.println("--------------------------------------------------------------");
                System.out.println("PROPERTY ID: " + property.PropertyId);
                System.out.println("PROPERTY ADDRESS: " + property.PropertyAddress);
                System.out.println("PROPERTY RENTAL AMOUNT: R" + property.PropertyRentalAmount);
                System.out.println("PROPERTY AGENT: " + property.AgentName);
                System.out.println("--------------------------------------------------------------");

                return property;
            }
        }

        // If not found
        System.out.println("------------------------------------------------------------");
        System.out.println("Property with Property Id: " + searchProperty + " was not found!");
        System.out.println("-----------------------------------------------------------");
        return null;
    }

    //Searches for a property using a provided id (useful for testing).
    public PropertyModel SearchPropertyById(String propertyId) {
        for (PropertyModel property : propertyList) {
            if (property.PropertyId.equals(propertyId)) {

            System.out.println("--------------------------------------------------------------");
                System.out.println("PROPERTY ID: " + property.PropertyId);
                System.out.println("PROPERTY ADDRESS: " + property.PropertyAddress);
                System.out.println("PROPERTY RENTAL AMOUNT: R" + property.PropertyRentalAmount);
                System.out.println("PROPERTY AGENT: " + property.AgentName);
                System.out.println("--------------------------------------------------------------");

                return property;
            }
        }

        System.out.println("------------------------------------------------------------");
        System.out.println("Property with Property Id: " + propertyId + " was not found!");
        System.out.println("-----------------------------------------------------------");
        return null;
    }

    //Updates an existing property by asking user for the propertyId and new values.
    public boolean UpdateProperty() {
        System.out.println("Enter the propertyId to update: ");
        String searchProperty = scanner.nextLine();

        for (PropertyModel property : propertyList) {

            if (property.PropertyId.equals(searchProperty)) {

                // Show current details
                System.out.println("--------------------------------------------------------------");
                System.out.println("PROPERTY ID: " + property.PropertyId);
                System.out.println("PROPERTY ADDRESS: " + property.PropertyAddress);
                System.out.println("PROPERTY RENTAL AMOUNT: R" + property.PropertyRentalAmount);
                System.out.println("PROPERTY AGENT: " + property.AgentName);
                System.out.println("--------------------------------------------------------------");

                // Update address
                System.out.print("Enter the property address: ");
                property.PropertyAddress = scanner.nextLine();

                // Update + validate rental amount
                double rentalAmount = 0;
                String propertyRentalAmount = "";

                do {
                    System.out.println("Enter the property rental amount: ");
                    propertyRentalAmount = scanner.nextLine();

                    try {
                        rentalAmount = Double.parseDouble(propertyRentalAmount);

                        if (!isRentalAmountValid(rentalAmount)) {
                            System.out.println("YOU HAVE ENTERED AN INVALID RENTAL AMOUNT!!!");
                            System.out.println("Please ENTER a VALID rental amount (R1500 or more)");
                        }

                    } catch (NumberFormatException e) {
                        rentalAmount = 0;
                        System.out.println("You have entered an invalid rental amount!!!");
                        System.out.println("Please re-enter rental amount (minimum R1500)");
                    }

                } while (!isRentalAmountValid(rentalAmount));
                
                property.PropertyRentalAmount = rentalAmount;

                // Update agent name
                System.out.print("Enter the property agent name: ");
                property.AgentName = scanner.nextLine();

                System.out.println("Property updated successfully!");
                return true;
            }
        }

        // Not found case
        System.out.println("------------------------------------------------------------");
        System.out.println("Property with Property Id: " + searchProperty + " was not found!");
        System.out.println("-----------------------------------------------------------");
        return false;
    }

    //Updates property by id using parameters (useful for tests).
    public boolean UpdatePropertyById(String propertyId, String newPropertyAddress, double newRentalAmount, String newAgentName) {
        if (!isRentalAmountValid(newRentalAmount)) return false;

        for (PropertyModel property : propertyList) {
            if (property.PropertyId.equals(propertyId)) {
                property.PropertyAddress = newPropertyAddress;
                property.PropertyRentalAmount = newRentalAmount;
                property.AgentName = newAgentName;
                return true;
            }
        }
        return false;
    }

    //Deletes a property by asking the user for propertyId and confirmation.
    public boolean DeleteProperty() {

        System.out.println("Enter the propertyId to delete:");
        String deletePropertyId = scanner.nextLine();

        System.out.println("Are you sure you want to delete Property ID: " + deletePropertyId +
                " from the system? Enter Yes(y) to delete.");
        String deleteConfirm = scanner.nextLine();

        // Anything other than y cancels deletion
        if (!deleteConfirm.equalsIgnoreCase("y")) {
            System.out.println("Delete cancelled.");
            return false;
        }

        // Search list and delete by index 
        for (int i = 0; i < propertyList.size(); i++) {
            if (propertyList.get(i).PropertyId.equals(deletePropertyId)) {
                propertyList.remove(i);
                System.out.println("Property with Property ID: " + deletePropertyId + " WAS deleted!");
                return true;
            }
        }

        System.out.println("Property with Property ID: " + deletePropertyId + " was not found!");
        return false;
    }

    //Deletes property by id (useful for testing).
    public boolean DeletePropertyById(String propertyId) {
        for (int i = 0; i < propertyList.size(); i++) {
            if (propertyList.get(i).PropertyId.equals(propertyId)) {
                propertyList.remove(i);
                return true;
            }
        }
        return false;
    }

    //Prints a report of all captured properties.
    public void PropertyRentalReport() {
        if (propertyList.isEmpty()) {
            System.out.println("------------------------------------------------------------");
            System.out.println("No properties in the system.");
            System.out.println("------------------------------------------------------------");
            return;
        }

        int count = 1;
        System.out.println("\n====== PROPERTY RENTAL REPORT ======\n");
        for (PropertyModel property : propertyList) {
            System.out.println("Property " + count);
            System.out.println("----------------------------------");
            System.out.println("PROPERTY ID: " + property.PropertyId);
            System.out.println("PROPERTY ADDRESS: " + property.PropertyAddress);
            System.out.println("PROPERTY RENTAL AMOUNT: R" + property.PropertyRentalAmount);
            System.out.println("PROPERTY AGENT: " + property.AgentName);
            System.out.println("---------------------------------------");
            count++;
        }
    }

    //Exits the Property Rentals application.
    public void ExitApplication() {
        System.out.println("Thank you for using Property Rentals Manager. Goodbye!");
        System.exit(0);
    }
}



                
            
           
            
      
