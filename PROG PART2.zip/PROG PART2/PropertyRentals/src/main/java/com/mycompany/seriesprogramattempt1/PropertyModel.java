package com.mycompany.seriesprogramattempt1;
//PropertyModel stores the details for property rentals.(This class is used by Property manager.)
public class PropertyModel {
  public String PropertyId;
  public String PropertyAddress;
  public double PropertyRentalAmount;
  public String AgentName;
  
}
