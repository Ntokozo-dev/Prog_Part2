package com.mycompany.seriesprogramattempt1;

import java.util.Scanner; // scanner for reading user input 


public class Property {

    public static void main(String[] args) {
        PropertyRentalsManager manager = new PropertyRentalsManager(); // object containing the working methods
        Scanner scanner = new Scanner(System.in); // use scanner to read user input
        String num = "1"; // the condition that controls the loop to keep launching the menu

        while (num.equals("1")) { // the loop that repeats as long as the user enters "1" at the menu prompt
            // Home screen (title + line) and menu prompt. User enters "1" to open menu.
            System.out.println("PROPERTY RENTALS - 2025");
            System.out.println("*************************************************************************************************************");
            System.out.print("Enter (1) to launch menu or any other key to exit: "); // prompt user for input
            num = scanner.nextLine();
            
            if (num.equals("1")) {
                // Menu Options plus prompt to select menu item
                System.out.println("--------------------------------------------------");    
                System.out.println("Please select one of the following menu items:");
                System.out.println("(1) Enter new property.");
                System.out.println("(2) Search for property.");
                System.out.println("(3) Update property.");
                System.out.println("(4) Delete a property.");
                System.out.println("(5) Print property report - 2025.");
                System.out.println("(6) Exit Application");
                System.out.println("----------------------------------------------------");
                System.out.print("Please select number (1-6): ");
                String choiceInput = scanner.nextLine(); // read whatever the user typed

                int choice;
                try {
                    choice = Integer.parseInt(choiceInput); // convert to int
                } catch (NumberFormatException e) {
                    choice = -1; // force default case for non-numbers
                }
  
                // SWITCH STATEMENT (MENU CONTROLLER): Runs the correct action based on the user's menu number
                switch(choice) {
                    case 1:
                        manager.EnterProperty();
                        break;
                    case 2:
                        manager.SearchProperty();
                        break;
                    case 3:
                        manager.UpdateProperty();
                        break;
                    case 4:
                        manager.DeleteProperty();
                        break;
                    case 5:
                        manager.PropertyRentalReport();
                        break;
                    case 6:
                        System.out.println("Exiting application...");
                        manager.ExitApplication();
                        break;
                    default:
                        System.out.println("Invalid choice. Please select 1-6.");
                }   
             
            } else { // exit logic for when user enters something other than "1" on the exit/menu prompt
                System.out.println("Exiting application...");
                System.exit(0);
            }
        }
    }
}

       
  



    

       
      
         

       
       
       
       
      
       
       
    


