/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.seriesprogramattempt1;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class PropertyRentalsTest {

    private PropertyRentalsManager manager;

    @Before
    public void setUp() { // runs before each test
        manager = new PropertyRentalsManager();
        manager.propertyList.clear(); // make sure no data from previous tests
    }
//tests that valid amounts (1500 and above) return true
    @Test
    public void TestPropertyRentalAmount_AmountValid() {
        assertTrue(manager.isRentalAmountValid(1500));
        assertTrue(manager.isRentalAmountValid(5000));
        assertTrue(manager.isRentalAmountValid(3500));
    }
//tests that invalid amounts (below 1500) return false
    @Test
    public void TestPropertyRentalAmount_AmountInvalid() {
        assertFalse(manager.isRentalAmountValid(1200));
        assertFalse(manager.isRentalAmountValid(0));
        assertFalse(manager.isRentalAmountValid(500));
        assertFalse(manager.isRentalAmountValid(1000));
    }
// adds a property and searches for it, confirms it's found with correct data
    @Test
    public void TestSearchProperty_ReturnsProperty() {
        PropertyModel property = new PropertyModel();
        property.PropertyId = "P101";
        property.PropertyAddress = "10 Main Road, 6001";
        property.PropertyRentalAmount = 3500.0;
        property.AgentName = "Joe Boggs";
        manager.propertyList.add(property);

        PropertyModel result = manager.SearchPropertyById("P101");

        assertNotNull(result);
        assertEquals("P101", result.PropertyId);
        assertEquals("10 Main Road, 6001", result.PropertyAddress);
        assertEquals(3500.0, result.PropertyRentalAmount, 0.001);
        assertEquals("Joe Boggs", result.AgentName);
    }
//searches for a non-existent ID, confirms null is returned
    @Test
    public void TestSearchProperty_PropertyNotFound() {
        PropertyModel result = manager.SearchPropertyById("P999");
        assertNull(result);
    }
//adds a property, updates it, confirms new values are saved
    @Test
    public void TestUpdateProperty() {
        PropertyModel property = new PropertyModel();
        property.PropertyId = "P101";
        property.PropertyAddress = "oldPropertyAddress";
        property.PropertyRentalAmount = 3500.0;
        property.AgentName = "New Agent";
        manager.propertyList.add(property);

        boolean updated = manager.UpdatePropertyById("P101", "newPropertyAddress", 2000.0, "New Agent");

        assertTrue(updated);

        PropertyModel updatedProperty = manager.SearchPropertyById("P101");
        assertNotNull(updatedProperty);
        assertEquals("newPropertyAddress", updatedProperty.PropertyAddress);
        assertEquals(2000.0, updatedProperty.PropertyRentalAmount, 0.001);
        assertEquals("New Agent", updatedProperty.AgentName);
    }
//adds a property, deletes it, confirms it no longer exists
    @Test
    public void TestDeleteProperty() {
        PropertyModel property = new PropertyModel();
        property.PropertyId = "P101";
        property.PropertyAddress = "To Delete";
        property.PropertyRentalAmount = 3500.0;
        property.AgentName = "Joe Bloggs";
        manager.propertyList.add(property);

        boolean deleted = manager.DeletePropertyById("P101");

        assertTrue(deleted);
        assertNull(manager.SearchPropertyById("P101"));
    }

}
